#
# Copyright="� Microsoft Corporation. All rights reserved."
#
try {
    Set-ExecutionPolicy -ExecutionPolicy Unrestricted 
}
catch{
    Write-Verbose 'An exception occurred setting Execution Policy - Trying to Continue -:'
    if ($Error) {
        Write-Verbose ($Error|fl * -Force|Out-String) 
    }
}


configuration SharePointServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,
        
        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]$DatabaseServer,
        
        [parameter(Mandatory)]
        [String]$Configuration,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60,

        [String]$DomainNetbiosName=$(if ($DomainName.Contains('.')) {$DomainName.Substring(0,$DomainName.IndexOf('.'))} else {$DomainName})

    )

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
    [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)

    # Install Sharepoint Module
       
    $ModuleFilePath="$PSScriptRoot\SharePointServer.psm1"
    $ModuleName = "SharepointServer"
    $PSModulePath = $Env:PSModulePath -split ";" | Select -Index 1
    $ModuleFolder = "$PSModulePath\$ModuleName"
    if (-not (Test-Path  $ModuleFolder -PathType Container)) {
       mkdir $ModuleFolder
    }
    Copy-Item $ModuleFilePath $ModuleFolder -Force

    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, cConfigureSharepoint

    # Enable CredSSP

    try {
        Enable-WSManCredSSP -Role Client -DelegateComputer "*.$Domain", localhost -Force
        Enable-WSManCredSSP -Role Server -Force
    }
    catch{
        Write-Warning 'An exception occurred enabling CredSSP - Trying to Continue -:'
        if ($Error) {
            Write-Warning ($Error|fl * -Force|Out-String) 
        }
    }

        
    Node localhost
    {
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }
        xDisk SPDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn = "[xDisk]SPDataDisk"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }


        xADUser CreateSetupAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SharePointSetupUserAccountcreds.UserName
            Password =$SharePointSetupUserAccountcreds
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPS", "[xComputer]DomainJoin"
        }

        Group AddSetupUserAccountToLocalAdminsGroup
        {
            GroupName = "Administrators"
            Credential = $DomainCreds
            MembersToInclude = "${DomainNetbiosName}\$($SharePointSetupUserAccountcreds.UserName)"
            Ensure="Present"
            DependsOn = "[xAdUser]CreateSetupAccount"
        }

        xADUser CreateFarmAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SharePointFarmAccountcreds.UserName
            Password =$FarmCreds
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPS", "[xComputer]DomainJoin"
        }
        
        cConfigureSharepoint ConfigureSharepointServer
        {
            DomainName=$DomainName
            DomainAdministratorCredential=$DomainCreds
            DatabaseName=$DatabaseName
            AdministrationContentDatabaseName=$AdministrationContentDatabaseName
            DatabaseServer=$DatabaseServer
            SetupUserAccountCredential=$SPsetupCreds
            FarmAccountCredential=$SharePointFarmAccountcreds
            FarmPassphrase=$SharePointFarmPassphrasecreds
            Configuration=$Configuration
            DependsOn = "[xADUser]CreateFarmAccount","[xADUser]CreateSetupAccount", "[Group]AddSetupUserAccountToLocalAdminsGroup"
        }

        #### Remove this if this gets fixed in the extension
        Script ResetExecutionPolicy
        {
            SetScript = "Set-ExecutionPolicy -ExecutionPolicy Default
                        Disable-WSManCredSSP -Role Client 
                        Disable-WSManCredSSP -Role Server"
            TestScript = "if ((Get-ExecutionPolicy) -eq 'Default') {`$true } else { `$false }"
            GetScript = "
                `$returnValue = @{
                    Ensure = if ((Get-ExecutionPolicy) -eq 'Default') {'Present'} else {'Absent'}
                }
                `$returnValue
                "
            DependsOn = "[cConfigureSharepoint]ConfigureSharepointServer" 
        }
    }
}

